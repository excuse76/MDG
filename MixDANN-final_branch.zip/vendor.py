import csv
import os
import shutil

with open('/home/wzc/zxr/MixDANN-final_branch/MixDANN-final_branch/MM&s/211230_M&Ms_Dataset_information_diagnosis_opendataset.csv','r') as csvfile:

    reader = csv.DictReader(csvfile)
    all = [row for row in reader]

    column = [row['Centre'] for row in all]
    name = [row['External code'] for row in all]
    vendor1 = []
    vendor2 = []
    vendor3 = []
    vendor4 = []
    vendor5 = []
    for i in range(len(column)):
        if column[i] == '1':
            vendor1.append(name[i])
        if column[i] == '2':
            vendor2.append(name[i])
        if column[i] == '3':
            vendor3.append(name[i])
        if column[i] == '4':
            vendor4.append(name[i])
        if column[i] == '5':
            vendor5.append(name[i])



root = "/home/wzc/zxr/MixDANN-final_branch/MixDANN-final_branch/MM&s/Validation/val"
root1="/home/wzc/zxr/MixDANN-final_branch/MixDANN-final_branch/MM&s/Validation"


dir=[]
for dirpath, dirnames, filenames in os.walk(root):

    dir.append(dirnames)
    break



for case in vendor5:
    ori_path=os.path.join(root,case)
    tar_path=os.path.join(root1,"5",case)
    if case in dir[0]:
        shutil.move(ori_path,tar_path)



