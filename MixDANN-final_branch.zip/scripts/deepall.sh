#!/bin/bash

random_seed=42

python  ../src/main.py \
    --gpu=0 \
    --save_dir=/deepall_testPerSubject_Utrecht_300epoch-rs$((42)) \
    --normal_aug \
    --wandb=wmh_seg_dg \
    --random_seed=42 \
    --max_num_epochs=300 \
    --batch_size=30 \
    --T1 \
    --single_target=Utrecht

python ../src/main.py \
    --gpu=0 \
    --save_dir=/deepall_testPerSubject_GE3T_300epoch-rs$((42)) \
    --normal_aug \
    --wandb=wmh_seg_dg \
    --random_seed=42 \
    --max_num_epochs=300 \
    --batch_size=30 \
    --T1 \
    --single_target=GE3T

python ../src/main.py \
    --gpu=0 \
    --save_dir=/deepall_testPerSubject_Singapore_300epoch-rs$((42)) \
    --normal_aug \
    --wandb=wmh_seg_dg \
    --random_seed=42 \
    --max_num_epochs=300 \
    --batch_size=30 \
    --T1 \
    --single_target=Singapore