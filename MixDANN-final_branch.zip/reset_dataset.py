import os
import shutil


join = os.path.join
addr = 'rename_data/2'

def reset_data(path):
    # find image and label
    subject_path_image = os.listdir(join(path, 'image'))
    subject_path_label = os.listdir(join(path, 'label'))
    subject_path_image.sort()
    subject_path_label.sort()

    # assert their length is same.
    assert len(subject_path_image) == len(subject_path_label)
    assert len(subject_path_image) != 0

    #
    for ipa in range(len(subject_path_image)):

        image_name = subject_path_image[ipa]
        label_name = subject_path_label[ipa]
        # not exists and create

        dst_dir = join(path, str(ipa))
        if not os.path.exists(dst_dir):
            os.makedirs(dst_dir)
        if not os.path.exists(join(dst_dir, 'pre')):
            os.makedirs(join(dst_dir, 'pre'))

        src_image = join(path, 'image', image_name)
        src_label = join(path, 'label', label_name)

        dst_image = join(dst_dir, 'pre', 'T1.nii.gz')
        dst_label = join(dst_dir, 'wmh.nii.gz')

        shutil.move(src_image, dst_image)
        shutil.move(src_label, dst_label)

        print("Try to move: ", image_name)
if __name__ == '__main__':
    reset_data(addr)